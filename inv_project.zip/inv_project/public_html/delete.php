<?php 

$id= $_GET['id'];


$conn = mysqli_connect('localhost','root','','project_inv');
$query1=mysqli_query($conn,"delete from invoice_details where invoice_no = '$id'");
$query=mysqli_query($conn,"delete from invoice where invoice_no = '$id'");

 if($query && $query1){
echo"<script> window.location.href = 'invoice_list.php'</script>";
echo "<script>alert('Invoice Deleted Successfully');</script>";

 }
 else{
    echo "<script>alert('Something went to wrong');</script>";
    echo"<script> window.location.href = 'invoice_list.php'</script>";
 }
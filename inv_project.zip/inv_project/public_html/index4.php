
	
	

<!DOCTYPE html>

<head>

<title> Search Data</title>

</head>
<body>
     <center>
    <h1> search data from database</h1>
     <form actiom="" method="POST">
     <input type="text" name="id" placeholder="Enter name"/><br>
     <input type="submit" name="search" value="serach data">
     </form>

    <?php
        $connection = mysqli_connect("localhost","root","");
        $db = mysqli_select_db($connection,"project_inv");

        if(isset($_POST['search']))
        {
            $name = $_POST['id'];

            $query = "SELECT * FROM clientdetails where client_name ='$name'";
            $query_run = mysqli_query($connection,$query);

            while($row = mysqli_fetch_array($query_run))
            {
                ?>

                <form action="" method="POST">

                <input type="hidden" name="name" value="<?php echo $row['id']?>"/>
                <input type="text" name="clientname" value="<?php echo $row['client_name']?>"/>
                <input type="text" name="address" value="<?php echo $row['address']?>"/>
                <input type="text" name="email" value="<?php echo $row['email']?>"/>
                <input type="text" name="phone" value="<?php echo $row['phone']?>"/>
                </form>
                <?php
            }
            
            
        }
    ?>
     </center>
</body>

</html>

<?php  
    include 'database/database.php';
    $value2='';
    //Query to fetch last inserted invoice number
    $query = "SELECT invoice_no from invoice order by invoice_no DESC LIMIT 1";
    $stmt = $conn->query($query);
    if(mysqli_num_rows($stmt) > 0) {
        if ($row = mysqli_fetch_assoc($stmt)) {
            $value2 = $row['invoice_no'];
            $items = (string)$value2;
            $items = substr($value2, 10, 13);//separating numeric part
            $items = $items + 1;//Incrementing numeric part
            $items = "ABC/19-20/" . sprintf('%03s', $value2);//concatenating incremented value
            $items = $items; 
        }
    } 
    else {
        $items = "ABC/19-20/001";
        $value = $items;
    }
    echo $value;//
?>
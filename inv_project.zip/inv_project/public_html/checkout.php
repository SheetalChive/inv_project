<?php

 session_start();
if(isset($_POST['login']))
{
    
    $log_email = $_POST['log_email'];
    $log_password = md5($_POST['log_password']);
    $pass_hash = password_hash($log_password,PASSWORD_BCRYPT,["cost"=>8]);
    
   
    $conn = mysqli_connect('localhost','root','','project_inv');
    $query=mysqli_query($conn,"SELECT * FROM user where `email`='$log_email' and `password`='$pass_hash'");

   
    if (mysqli_num_rows($query) == 1) 
    {
       
        $_SESSION["email"]=$row['email'];
        $_SESSION["username"]=$row['username'];
    
        $_SESSION['success']="Login Success";
        echo "<script>window.location.href='dashboard.php';</script>";
    }
    else
    {
        echo "<script>alert('Invalid Email ID/Password');</script>";
        echo "<script>window.location.href='index.php';</script>";
    }
}
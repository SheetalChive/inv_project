<?php

	include_once("dashboard1.php");
?>
  <div class="content-wrapper">
    <div class="container-fluid">                       
<?php



//$sname= "localhost";
//$unmae= "root";
//$password = "";

//$db_name = "test_db";

//$conn = mysqli_connect($sname, $unmae, $password, $db_name);

//if (!$conn) {
//	echo "Connection failed!";
//} 


	$clientName = $_POST['clientName'];
	$address = $_POST['address'];
	//$gender = $_POST['gender'];
	$email = $_POST['email'];
	//$password = $_POST['password'];
	$number = $_POST['number'];

	// Database connection
	$conn = new mysqli('localhost','root','','project_inv');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into clientdetails(client_name,address, email, phone_no) values(?, ?, ?, ?)");
		$stmt->bind_param("sssi", $clientName, $address, $email,$number);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfull..";
		$stmt->close();
		$conn->close();
	}
<?php
session_start();

include_once("../fpdf/fpdf.php");


class myPDF extends FPDF
{
	function header()
	{
		$this->Image('logo2.jpg',10,5,-350);
		//$this->setFont('Arial','B',14);
		$this->setFont("Arial","B",16);
	    $this->Cell(190,10,"QUATATION",0,1,"R");
	    $this->setFont("Arial",null,12);
		//$this->Cell(276,5,'QUATATION',0,0,'R');
		//$this->Ln();
		$this->SetTextColor(255,69,0);
	    $this->setFont("Arial","B",10);
		$this->Cell(161,5,"INVOICE NO",0,0,"R");
	    $this->Cell(165,5,"				: DEG".$_GET["invoice_no"],0,1);
	    $this->Cell(165,5,"BILLING DATE",0,0,"R");
	    $this->Cell(165,5,": ".$_GET["order_date"],0,1);
		$this->Cell(158,5,"DUE DATE",0,0,"R");
	    $this->Cell(165,5,"       : ".$_GET["due_date"],0,1);
		$this->Ln();
		$this->Ln();
		// $this->Ln();

	}

	
	

	function footer()
	{
		$this->SetY(-15);
		$this->setFont('Arial','',8);
		$this->Cell(0,10,'page'.$this->PageNo().'/{nb}',0,0,'C');
	}


	function headerTable()
	{
	    $this->Ln();	
		$this->setFont('Times','B',10);
		$this->SetFillColor(255,69,0);
		$this->SetTextColor(255,255,255);
		$this->Cell(90,6,"BILLING FROM",0,0,"C",true); 
		
		
		$this->Cell(5);

		$this->Cell(95,6,"BILLING TO",0,0,"C",true);
		$this->Ln();
		$this->SetTextColor(0,0,0);
		

		

}
    function headerTable1()
    {	
	$this->setFont('Times','B',10);
	
	$this->Cell(95	,10,'DAGADE EVENTS',0,0);
	//$this->Cell(55,9,$_GET["category_item"],0,1,"R");
	$this->Cell(25	,9,$_GET["name"],0,0);
    $this->Cell(34	,7, "",0,1);
	$this->SetTextColor(167,167,167);
	$this->Cell(95	,5,'KRISHNA PLAZA,NEAR COMMINS COLLEGE,',0,0);
	$this->Cell(25	,5,$_GET["address"],0,0);
	$this->Cell(34	,5, "",0,1);
	$this->Cell(95	,5,'KARVE NAGAR,PUNE-411052',0,0);
	$this->Cell(25	,5,$_GET["address1"],0,0);
	$this->Cell(34	,5, "",0,1);
	$this->Cell(95	,5,'7083791202',0,0);
	$this->Cell(25	,5,$_GET["contact"],0,0);
	$this->Cell(34	,5, "",0,1);
	$this->Cell(95	,5,'dineshdagade04@gmail.com',0,0);
	$this->Cell(25	,5,$_GET["email"],0,0);
	$this->Cell(34	,5, "",0,1);
	$this->SetTextColor(0,0,0);

	// $this->Ln();  
    

	// function headerTable2()
    // {	
	// $this->setFont('Times','B',10);
	// $this->SetTextColor(167,167,167);
	// $this->Cell(80	,10,'DAGADE EVENTS',0,0);
	// $this->Cell(59	,10,'',0,1);
	// $this->SetTextColor(167,167,167);
	

	// $this->Ln();
    

    }
	function headerTable3()
	{
		$this->setFont('Times','B',10);
		$this->SetFillColor(255,69,0);
		$this->SetDrawColor(255, 255, 255);
		$this->ln();
		$this->SetTextColor(255,255,255);
		$this->Cell(100,8,"PRODUCT",1,0,"C",true);
		// $this->Cell(30,10,"QUANTITY",1,0,"C",true);
		// $this->Cell(40,10,"PRICE",1,0,"C",true);
		$this->Cell(92,8,"TOTAL",1,1,"C",true);
		//$this->Cell(50,10,"Sub Total",1,1,"c",true);
		//$this->Ln();
		$this->SetTextColor(0,0,0);

		

}

	function viewTable()
	{
        for ($i=0; $i < count($_GET["pid"]) ; $i++) { 
			// $pdf->Cell(10,10, ($i+1) ,1,0,"C");
			$this->SetFillColor(230,230,230);
			$this->Cell(100,8, $_GET["pid"][$i],1,0,"C",true);
			// $this->Cell(30,10, $_GET["qty"][$i],1,0,"C",true);
			// $this->Cell(40,10, $_GET["price"][$i],1,0,"C",true);
			$this->Cell(92,8, (1 * $_GET["price"][$i]) ,1,1,"C",true);
			
        	//$this->Cell(50,10,$_GET["sub_total"],1,0,"C",true);
			 //$this->Ln();
			// $this->Ln();

		}
	}

	 function viewTable1()
	 {
	 	$this->Cell(50,0,"",0,1,"R");
		$this->setFont('Times','B',10);
		//$this->Cell(100);
		$this->Cell(100,8,"Sub Total",1,0,"C",true);
	    $this->Cell(92,8,"INR  ".$_GET["sub_total"],1,0,"C",true);
	// $this->Cell(50,10,"Gst Tax",0,0);
	// $this->Cell(50,10,": ".$_GET["gst"],0,1);
	// $this->Cell(50,10,"Discount",0,0);
	// $this->Cell(50,10,": ".$_GET["discount"],0,1);
	   $this->Ln();
	   //$this->Cell(100);
	   $this->SetFillColor(255,69,0);
	   $this->SetTextColor(255,255,255);
	   $this->Cell(100,8,"Total",1,0,"C",true);
	   $this->Cell(92,8,"INR  ".$_GET["net_total"],1,0,"C",true);
	// $this->Cell(50,10,"Paid",0,0);
	// $this->Cell(50,10,": ".$_GET["paid"],0,1);
	// $this->Cell(50,10,"Due Amount",0,0);
	// $this->Cell(50,10,": ".$_GET["due"],0,1);
	// $this->Cell(50,10,"Payment Type",0,0);
	// $this->Cell(50,10,": ".$_GET["payment_type"],0,1);
	$this->Ln();
	 }
            
	         
	        
			function viewTable2()
			{
			$this->Ln();
			$this->setFont('Times','B',10);
			$this->SetFillColor(255,69,0);
			$this->SetTextColor(255,255,255);
			$this->Cell(95,6,"TERMS & CONDITIONS:",0,0,"C",true);
			$this->Ln(); 
			$this->SetTextColor(167,167,167);
			$this->Cell(80	,10,'1.Project working will start when 80% advance is paid by client.',0,0);
	        $this->Cell(59	,5,'',0,1);
			$this->Cell(80	,10,'2.The Firm is responsive for given months of year is responsive.',0,0);
	        $this->Cell(59	,5,'',0,1);
			$this->Cell(80	,10,'3.Advance can not be refundable.,',0,0);
	        $this->Cell(59	,5,'',0,1);
			$this->Cell(80	,10,'4.Price is totally depends on the requirements.,',0,0);
	        $this->Cell(59	,5,'',0,1);
			$this->Cell(80	,10,'5.If the requirement changes, prices will be changes simulteniously.',0,0);
	        $this->Cell(59	,5,'',0,1);
			$this->Cell(80	,10,'6.All the requirements as per the Information given by the client.',0,0);
	        $this->Cell(59	,5,'',0,1);
			$this->Cell(80	,10,'7.Client should check it before signing this document.',0,0);
	        $this->Cell(59	,5,'',0,1);
			$this->Cell(80	,10,'8.GST should be extra on chosen packege.',0,0);
	        $this->Cell(59	,5,'',0,1);
			$this->Cell(80	,10,'9.In case of cancellation of Photography and videography by the client.',0,0);
	        $this->Cell(59	,5,'',0,1);
			$this->Cell(85	,10,'50% of the decided amount will be non_refundable.',0,0);
	        $this->Cell(59	,5,'',0,1);
		    $this->SetTextColor(0,0,0);
			$this->Cell(1);
			$this->Cell(180,5,"--------------------------",0,1,"R");
			$this->Cell(180,5,"DAGADE EVENTS",0,1,"R");
			// $this->Ln();
		    $this->setFont("Arial","",9);
			// $this->Cell(1);
			// $this->Cell(180,10,"--------------------------",0,1,"R");
			// $this->Cell(180,0,"DAGADE EVENTS",0,1,"R");
	        $this->Cell(190,5,"BANK ACCOUNT DETAILS:",0,1,);
			$this->Cell(30,5,"DAGADE EVENTS",0,0,);
			$this->cell(60,5,"ACCOUNT NUMBER-50200053803316",0,0,);
			$this->Cell(80,5,"IFSC CODE-HDFC0000149",0,0,);
			
	        $this->setFont("Arial",null,12);
			
			$this->Ln();
			$this->Cell(190,20,"Thank You For Your Business!",0,1,"C");
	
	}	
}

$pdf = new myPDF();
//$pdf->SetMargins(10,60,10);
$pdf->AliasNbPages();
$pdf->AddPage();


$pdf->headerTable();
$pdf->headerTable1();
//$pdf->headerTable2();
$pdf->headerTable3();
$pdf->viewTable();
$pdf->viewTable1();
$pdf->viewTable2();
$pdf->Output("../PDF_INVOICE/PDF_INVOICE_".$_GET["invoice_no"].".pdf","F");
$pdf->Output();
?>

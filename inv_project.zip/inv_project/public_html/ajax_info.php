<?php 

$id= $_GET['id'];
// echo $id;
$conn = mysqli_connect('localhost','root','','project_inv');
$query=mysqli_query($conn,"select * from clientdetails where id = '$id'");
while($row=mysqli_fetch_array($query)){
    $name=$row['client_name'];
    $address=$row['address'];
	$address1=$row['address1'];
    $email=$row['email'];
    $phone=$row['phone'];
}
?>
    <div class="row">
   
		<input type="hidden" id="name" name="name" readonly class="form-control form-control-sm" value="<?php echo $name; ?>">
			
	
    <div class="form-group col-md-4">
		<label class=" col-form-label" align="right">Address-1</label>
			<div class="">
				<textarea  id="address" name="address" rows=1; readonly class="form-control form-control-sm" ><?php echo $address  ?></textarea>
			</div>
	</div>
	<div class="form-group col-md-4">
		<label class=" col-form-label" align="right">Address-2</label>
			<div class="">
				<textarea  id="address1" name="address1" rows=1; readonly class="form-control form-control-sm" ><?php echo $address1  ?></textarea>
			</div>
	</div>
    <div class="form-group col-md-4">
		<label class=" col-form-label" align="right">Email</label>
			<div class="">
				<input type="email" id="email" name="email" readonly class="form-control form-control-sm" value="<?php echo $email; ?>"">
			</div>
	</div>
    
    <div class="form-group col-md-4">
		<label class="col-form-label" align="right">Contact Number</label>
			<div class="">
				<input type="text" id="contact" name="contact" readonly class="form-control form-control-sm" value="<?php echo $phone  ?>">
			</div>
	</div>
</div>



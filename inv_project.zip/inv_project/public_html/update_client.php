<?php
// include_once("./database/constants.php");
// if (!isset($_SESSION["userid"])) {
// 	header("location:".DOMAIN."/");
// }
session_start();
if(!isset($_SESSION["username"])){
	echo "<script>window.location.href='index.php';</script>";
}
$username=$_SESSION['username'];

?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Dagade Events</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Inventory Management System</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
 	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 	<script type="text/javascript" src="./js/order.js"></script>
 </head>
<body>


<body class="fixed-nav sticky-footer bg-dark" id="page-top">
<?php include_once("dashboard1.php"); ?>

<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <!-- <ol class="breadcrumb"> -->
        <!-- <li class="breadcrumb-item"> -->
          <!-- <a href="create_invoice.php">Create Invoice</a> -->
        <!-- </li> -->
        <!-- <li  class="breadcrumb-item active" ><a href="invoice_list.php">Invoice List</li> -->
      <!-- </ol> -->
<div class="overlay"><div class="loader"></div></div>
	<!-- Navbar -->
	<?php 
    	 
         $id = $_GET['id'];
       
          $conn=mysqli_connect('localhost','root','','project_inv');
          $query=mysqli_query($conn, "select * from clientdetails where id= $id");
          while($row=mysqli_fetch_array($query)){
              $name=$row['client_name'];
              $email=$row['email'];
              $address=$row['address'];
              $address1=$row['address1'];
              $phone=$row['phone'];
          }
		 
     ?>


	<div class="container">
		<div class="row">
			<div class="col-md-10 mx-auto">
				<div class="card" style="box-shadow:0 0 25px 0 lightgrey;">
				  <div class="card-header">
				   	<h4>Add Client</h4>
				  </div>
				  <div class="card-body">
                    <form  method="post">
                        <div class="form-group row">
                            <label for="client_name" class="col-sm-3 col-form-label" align="right">Client Name:</label>
                            <div class="col-sm-6">
                                <input type="text"class="form-control" id="clientName" name="name" autocomplete="off" value="<?php echo $name; ?>"  placeholder="Enter your Name" required/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="address" class="col-sm-3 col-form-label" align="right">Address-1:</label>
                            <div class="col-sm-6">
                                <textarea type="text"class="form-control" id="address" name="address" required><?php echo $address; ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="address" class="col-sm-3 col-form-label" align="right">Address-2:</label>
                            <div class="col-sm-6">
                                <textarea type="text"class="form-control" id="address1" name="address1" required><?php echo $address1; ?></textarea>
                            </div>
                        </div>
                
                        <div class="form-group row">
                            <label for="email" class="col-sm-3 col-form-label" align="right">Email:</label>
                            <div class="col-sm-6">
                                <input type="email" class="form-control" pattern="[^ @]*@[^ @]*" autocomplete="off" id="email" value="<?php echo $email; ?>" name="email"  placeholder="Enter your email" required/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="number" class="col-sm-3 col-form-label" align="right">Phone Number:</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" maxlength="10" autocomplete="off" id="phone" name="phone" value="<?php echo $phone; ?>"  placeholder="Enter your email" required/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-3"></div>
                            <div class="col-sm-6  text-center">
                                <input type="submit" name="submit" value="Submit" class="btn btn-primary" />
                                <a href="client_list.php" class="btn btn-danger">Cancel</a>
                            </div>
                        </div>
                    </form>

				  </div>
				</div>
			</div>
		</div>
	</div>
<!-- </div>
</div> -->
<?php 
if(isset($_POST['submit'])){
echo "<script>alert('hii');</script>";
$name=$_POST['name'];
$address=$_POST['address'];
$address1=$_POST['address1'];
$email=$_POST['email'];
$phone=$_POST['phone'];

$query=mysqli_query($conn, "UPDATE `clientdetails` SET `client_name`='$name',`email`='$email',`address`='$address', `address1`='$address1',`phone`='$phone' WHERE id='$id'") or die(mysqli_error($conn));
echo "<script>window.location.href='client_list.php';</script>";
echo "<script>alert('Client Updated Successfully....!!!!');</script>";
}

?>

</body>

</html>
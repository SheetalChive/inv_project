<?php
// include_once("./database/constants.php");
// if (!isset($_SESSION["userid"])) {
// 	header("location:".DOMAIN."/");
// }
session_start();
if(!isset($_SESSION["username"])){
	echo "<script>window.location.href='index.php';</script>";
}
$username=$_SESSION['username'];

?>
<?php include_once("dashboard1.php"); 

?>

<?php include("database/database.php")?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>DAGADE EVENTS</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
	
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
 	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 	<link rel="stylesheet" href="css/style1.css">
	 <script type="text/javascript" src="./js/main.js"></script>
	 <script src="js/ajax.js"></script>
	 <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
 	
 </head>

<body>
  <div class="content-wrapper">
    <div class="container-fluid">

<br>
<br>
<style>
.center {
  margin: auto;
  width: 60%;
  border: 3px solid #28a4c9;
  padding: 10px;
}
</style>

<h2><center>Terms & Conditions</center></h2>


<div class="center">
<ul>
								<li>Project working will start when 80% advance is paid by client.</li>
								<li>The Firm is responsive for given months of year is responsive</li>
								<li>Advance can't be refundable.</li>
								<li>Price is totally depends on the requirements.</li>
								<li>If the requirement changes, prices will be changes simulteniously.</li>
								<li>All the requirements as per the Information given by the client.</li>
								<li>Client should check it before signing this document.</li>
								<li>GST should be extra on chosen packege.</li>
								<li>In case of cancellation of Photography and videography by the client,50% of the decided amount will be non_refundable.</li>
								
							</ul> 
</div>

</body>
</html>
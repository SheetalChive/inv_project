<?php 
	if(isset($_POST['update'])){
		echo "<script>alert('hii');</script>";
		$updateId=$_POST['id_u'];
		echo "<script>alert($updateId)</script>";
		// $updateName=$_POST['name_u'];
		// $updateEmail=$_POST['email_u'];
		// $updatePhone=$_POST['phone_u'];
		// $updateAddress=$_POST['address_u'];

		// $query1=mysqli_query($conn,"UPDATE `clientdetails` SET `client_name`='$updateName',`address`='$updateAddress',`email`='$updateEmail',`phone`='$updatePhone' WHERE id=$updateId") or die(mysqli_error($conn));
		// echo "<script>window.location.href='client_list.php';</script>";
		
	}

?>
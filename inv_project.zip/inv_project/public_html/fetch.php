<?php
  $editId = $_POST['rowid'];
  echo $editId;
   $conn=mysqli_connect('localhost','root','','project_inv');
   $query=mysqli_query($conn, "select * from clientdetails where id= $editId");
   while($row=mysqli_fetch_array($query)){
       $name=$row['client_name'];
       $email=$row['email'];
       $address=$row['address'];
       $phone=$row['phone'];
   }
  ?>
<input type="hidden" id="id_u"  value=<?php echo $editId; ?> name="id_u" class="form-control" required>					
  <div class="form-group">
      <label>Name</label>
      <input type="text" id="name_u" value=<?php echo $name; ?> name="name_u" class="form-control" required>
  </div>
  <div class="form-group">
      <label>Email</label>
      <input type="email" id="email_u" value=<?php echo $email; ?> name="email_u" class="form-control" required>
  </div>
  <div class="form-group">
      <label>PHONE</label>
      <input type="phone" id="phone_u" value=<?php echo $phone; ?> name="phone_u" class="form-control" required>
  </div>
  <div class="form-group">
      <label>Address</label>
      <input type="text" id="address_u" value=<?php echo $address; ?> name="address_u" class="form-control" required>
  </div>



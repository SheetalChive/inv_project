<?php

$connect = new PDO("mysql:host=localhost;dbname=project_inv", "root", "");

if(isset($_POST["type"]))
{
 if($_POST["type"] == "category_data")
 {
  $query = "
  SELECT * FROM clientdetails 
  ORDER BY Client_name ASC
  ";
  $statement = $connect->prepare($query);
  $statement->execute();
  $data = $statement->fetchAll();
  foreach($data as $row)
  {
   $output[] = array(
    'id'  => $row["id"],
    'name'  => $row["client_name"]
   );
  }
  echo json_encode($output);
 }
 else
 {
  $query = "
  SELECT * FROM clientdetails
  WHERE id = '".$_POST["category_id"]."' 
  ORDER BY address ASC
  ";
  $statement = $connect->prepare($query);
  $statement->execute();
  $data = $statement->fetchAll();
  foreach($data as $row)
  {
   $output[] = array(
    'id'  => $row["address"],
    'name'  => $row["address"]
   );
  }
  echo json_encode($output);
 }
}

?>
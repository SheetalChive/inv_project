<?php
require_once "config.php";
 
 // Define variables and initialize with empty values
 $name = $address = $email = $phone = "";
 $name_err = $address_err = $email_err = $phone_err ="";
  
 // Processing form data when form is submitted
 if($_SERVER["REQUEST_METHOD"] == "POST"){
     // Validate name
     $input_name = trim($_POST["name"]);
     if(empty($input_name)){
         $name_err = "Please enter a name.";
     } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
         $name_err = "Please enter a valid name.";
     } else{
         $name = $input_name;
     }
     
     // Validate address
     $input_address = trim($_POST["address"]);
     if(empty($input_address)){
         $address_err = "Please enter an address.";     
     } else{
         $address = $input_address;
     }
 
     $input_email = trim($_POST["email"]);
     if(empty($input_email)){
         $email_err = "Please enter a name.";
     } elseif(!filter_var($input_email, FILTER_VALIDATE_EMAIL)) {
         $email_err = "Please enter a valid name.";
     } else{
         $email = $input_email;
     }
     
     // Validate salary
     
 
     $input_phone = trim($_POST["phone"]);
     if(empty($input_phone)){
         $phone_err = "Please enter the salary amount.";     
     } elseif(!ctype_digit($input_phone)){
         $phone_err = "Please enter a positive integer value.";
     } else{
         $phone = $input_phone;
     }
     
     // Check input errors before inserting in database
     if(empty($name_err) && empty($address_err) && empty($email_err) && empty($phone_err)){
         // Prepare an insert statement
         $sql = "INSERT INTO clientdetails (client_name,address,email,phone_no) VALUES (?, ?, ?,?)";
          
         if($stmt = mysqli_prepare($link, $sql)){
             // Bind variables to the prepared statement as parameters
             mysqli_stmt_bind_param($stmt, "sssi", $param_name, $param_address, $param_email,$param_phone);
             
             // Set parameters
             $param_name = $name;
             $param_address = $address;
             $param_email = $email;
             $param_phone = $phone;
             
             // Attempt to execute the prepared statement
             if(mysqli_stmt_execute($stmt)){
                 // Records created successfully. Redirect to landing page
                 header("location: client_list.php");
                 exit();
             } else{
                 echo "Something went wrong. Please try again later.";
             }
         }
          
         // Close statement
         mysqli_stmt_close($stmt);
     }
     
     // Close connection
     mysqli_close($link);
 }?>
<!-- Modal -->
<div class="modal fade" id="form_products" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add new client</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <form action="#" method="post">
      <!-- <form action="db_conn.php" method="post"> -->
              <div class="form-group">
                <label for="clientName">Client Name:</label>
                <input
                  type="text"
                  class="form-control"
                  id="clientName"
                  name="clientName" placeholder="Enter your Name" required
                />
              </div><br>
              <div class="form-group">
                <label for="address">Address:</label>
                <input
                  type="text"
                  class="form-control"
                  id="address"
                  name="address" placeholder="Enter your address" required
                />
              </div><br>
              
              
              <div class="form-group">
                <label for="email">Email:</label>
                <input
                  type="text"
                  class="form-control"
                  id="email"
                  name="email" pattern="[^ @]*@[^ @]*" placeholder="Enter your email" required

                />
                
              </div><br>
              
              <div class="form-group">
                <label for="number">Phone Number:</label>
                <input
                  type="number"
                  class="form-control"
                  id="number"
                  name="number"   pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" placeholder="Enter your phone No" required
                />
              </div><br><br>
              <input type="submit" class="btn btn-primary" />
              <a href="client_list.php" class="btn btn-primary">view</a>
            </form>
            
             
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<?php
$clientName = $_POST['clientName'];
	$address = $_POST['address'];
	//$gender = $_POST['gender'];
	$email = $_POST['email'];
	//$password = $_POST['password'];
	$number = $_POST['number'];

	// Database connection
	$conn = new mysqli('localhost','root','','project_inv');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into clientdetails(client_name,address, email, phone_no) values(?, ?, ?, ?)");
		$stmt->bind_param("sssi", $clientName, $address, $email,$number);
		$execval = $stmt->execute();
		// echo $execval;
    if($execval)
    {
      echo "<script>".
        "alert('New Client Added SuccessFully');".
        "</script>";
    }
		// echo "Registration successfull..";
		$stmt->close();
		$conn->close();
	}
  ?>


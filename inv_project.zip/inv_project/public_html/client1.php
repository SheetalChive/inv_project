<?php
// include_once("./database/constants.php");
// if (!isset($_SESSION["userid"])) {
// 	header("location:".DOMAIN."/");
// }
session_start();
if(!isset($_SESSION["username"])){
	echo "<script>window.location.href='index.php';</script>";
}
$username=$_SESSION['username'];

?>
<?php include_once("dashboard1.php"); 

?>

<?php include("database/database.php")?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>DAGADE EVENTS</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
	
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
 	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 	<link rel="stylesheet" href="css/style1.css">
	 <script type="text/javascript" src="./js/main.js"></script>
	 <script src="js/ajax.js"></script>
	 <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
 	
 	
	
	
    
    
	
	
	 
	 
 </head>
<body>
	<!-- Navbar -->




  <div class="content-wrapper">
    <div class="container-fluid">
	<br><br>
<h2><center>Add Client Details</center></h2>
<br><br>
	<p></p>
	<p></p>
	<div class="container">
		<div class="row">
			<!-- <div class="col-md-4">
				<div class="card">
						<div class="card-body">
						<h4 class="card-title">Category</h4>
						<p class="card-text">Here you can manage your categories and you add new parent and sub categories</p>
						<a href="#" data-toggle="modal" data-target="#form_category" class="btn btn-primary"> Category</a>						
						<a href="manage_categories.php" class="btn btn-primary">Manage</a>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card">
						<div class="card-body">
						<h4 class="card-title">Brands</h4>
						<p class="card-text">Here you can manage your brand and you add new brand</p>
						<a href="#" data-toggle="modal" data-target="#form_brand" class="btn btn-primary"> Brand</a>						
						<a href="manage_brand.php" class="btn btn-primary">Manage</a>
					</div>
				</div>
			</div> -->
            <center>
			<p id="success"></p>
			<div class="col-md-4">
				<div class="card">
						<div class="card-body">
						
						<h4 class="card-title">Add New Client</h4>
						<p class="card-text">Here you can manage your Client and you add new Clients</p>
						<!-- <a href="#" data-toggle="modal" data-target="#form_products" class="btn btn-primary"> Add Client</a> -->
						<a href="create_client.php" class="btn btn-success" >	<span>Add Client</span></a>

						<a href="client_list.php" class="btn btn-primary">Manage</a>
					</div>
				</div>
			</div>
            </center>
		</div>
	</div>



	</div> 
	<?php
	//Categpry Form
	// include_once("./templates/category.php");
	 ?>
	 <?php
	//Brand Form
	// include_once("./templates/brand.php");
	 ?>
	 <?php
	//Products Form
	// include_once("./templates/clients1.php");
	include_once("./database/database.php");
	 ?>


</body>
</html>
<div id="addEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="user_form" method="post">
					<div class="modal-header">						
						<h4 class="modal-title">Add Client</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<div class="form-group">
							<label>NAME</label>
							<input type="text" id="name" name="name" class="form-control" required>
						</div>
						<div class="form-group">
							<label>EMAIL</label>
							<input type="email" id="email" name="email" class="form-control" required>
						</div>
						<div class="form-group">
							<label>PHONE</label>
							<input type="phone" id="phone" name="phone" class="form-control" required>
						</div>
						<div class="form-group">
							<label>ADDRESS-1</label>
							<input type="text" id="address" name="address" class="form-control" required>
						</div>	
						<div class="form-group">
							<label>ADDRESS-2</label>
							<input type="text" id="address2" name="address2" class="form-control" required>
						</div>				
					</div>
					<div class="modal-footer">
					    <input type="hidden" value="1" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="submit" name="add" class="btn btn-success" id="btn-add">Add</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	
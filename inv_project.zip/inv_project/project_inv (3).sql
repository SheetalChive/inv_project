-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2021 at 09:18 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_inv`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `bid` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`bid`, `brand_name`, `status`) VALUES
(1, 'Samsung', '1'),
(13, 'HP', '1'),
(14, 'Huawei', '1'),
(15, 'Microsoft Corporation', '1'),
(16, 'Adobe', '1'),
(17, 'Apple', '1'),
(18, 'Avira', '1');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cid` int(11) NOT NULL,
  `parent_cat` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cid`, `parent_cat`, `category_name`, `status`) VALUES
(1, 0, 'Electronics', '1'),
(2, 0, 'Software', '1'),
(5, 1, 'Mobiles', '1'),
(7, 1, 'Laptop', '1'),
(9, 2, 'Antivirus', '1'),
(10, 0, 'Gadgets', '1');

-- --------------------------------------------------------

--
-- Table structure for table `clientdetails`
--

CREATE TABLE `clientdetails` (
  `id` int(11) NOT NULL,
  `client_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `address1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `clientdetails`
--

INSERT INTO `clientdetails` (`id`, `client_name`, `email`, `address`, `address1`, `phone`) VALUES
(107, 'Apurva', 'sangita@gmail.com', 'ff', '', '2324322'),
(124, 'SAI KOLEKAR', 'sai12@gmail.com', 'GALLI NO-2A, SHIV SHAMBHO NAGAR', '', ''),
(132, 'Rahul', 'rk12@gmail.com', 'cde', '', '2147483647'),
(133, 'SHEETAL KOLEKAR', 'sk122@gmail.com', 'GALLI NO-2A, SHIV SHAMBHO NAGAR', '', ''),
(135, 'KOMAL KOLEKAR', 'komalk99@gmail.com', 'HHASBHFJSBVHBRHFBNDBVNBV', 'FBDVBCBVXCNGVHDJKGJDFNB', '9850026315'),
(136, 'PHOTOGRAPHER PATEL', '', 'GAHUNJE', 'PUNE', '7208188749');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_no` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `order_date` date NOT NULL,
  `sub_total` double NOT NULL,
  `gst` double NOT NULL,
  `discount` double NOT NULL,
  `net_total` double NOT NULL,
  `paid` double NOT NULL,
  `due` double NOT NULL,
  `payment_type` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_no`, `customer_name`, `order_date`, `sub_total`, `gst`, `discount`, `net_total`, `paid`, `due`, `payment_type`) VALUES
(71, 'SAI KOLEKAR', '2021-12-03', 92660, 16678.8, 0, 109338.8, 0, 109338.8, 'Cash'),
(72, 'Rahul', '2021-12-03', 0, 0, 0, 0, 0, 0, 'Cash'),
(73, 'PHOTOGRAPHER PATEL', '2021-12-03', 0, 0, 0, 0, 0, 0, 'Cash'),
(75, 'PHOTOGRAPHER PATEL', '0000-00-00', 300, 54, 0, 354, 0, 354, 'Cash'),
(76, 'KOMAL KOLEKAR', '0000-00-00', 0, 0, 0, 0, 0, 0, 'Cash'),
(77, 'Rahul', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(78, 'SHEETAL KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(79, 'SHEETAL KOLEKAR', '0000-00-00', 0, 0, 0, 0, 0, 0, 'Cash'),
(80, 'KOMAL KOLEKAR', '0000-00-00', 200, 36, 0, 236, 100, 136, 'Cash'),
(81, 'KOMAL KOLEKAR', '0000-00-00', 29000, 5220, 0, 34220, 100, 34120, 'Cash'),
(82, 'KOMAL KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(83, 'KOMAL KOLEKAR', '0000-00-00', 29000, 5220, 0, 34220, 0, 34220, 'Cash'),
(84, 'KOMAL KOLEKAR', '0000-00-00', 5000, 900, 0, 5900, 1000, 4900, 'Cash'),
(85, 'PHOTOGRAPHER PATEL', '0000-00-00', 29000, 5220, 0, 34220, 0, 34220, 'Cash'),
(86, 'PHOTOGRAPHER PATEL', '0000-00-00', 29000, 5220, 0, 34220, 100, 34120, 'Cash'),
(87, 'SHEETAL KOLEKAR', '0000-00-00', 200, 36, 0, 236, 0, 236, 'Cash'),
(88, 'SHEETAL KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(89, 'SAI KOLEKAR', '0000-00-00', 29000, 5220, 0, 34220, 0, 34220, 'Cash'),
(90, 'PHOTOGRAPHER PATEL', '0000-00-00', 29000, 5220, 0, 34220, 0, 34220, 'Cash'),
(91, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 100, 18, 0, 118, '0'),
(92, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 300, 54, 0, 354, '0'),
(93, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 200, 36, 0, 236, '0'),
(94, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 0, 0, 0, 0, '0'),
(95, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 200, 36, 0, 236, '0'),
(96, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 100, 18, 0, 118, '0'),
(97, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 100, 18, 0, 118, '0'),
(98, 'PHOTOGRAPHER PATEL', '0000-00-00', 100, 18, 0, 118, 0, 118, '0'),
(99, 'PHOTOGRAPHER PATEL', '0000-00-00', 100, 18, 0, 118, 0, 118, '0'),
(100, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 100, 18, 0, 118, 0, '118'),
(101, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 100, 18, 0, 118, 0, '118'),
(102, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 100, 18, 0, 118, '0'),
(103, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 100, 18, 0, 118, '0'),
(104, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 100, 18, 0, 118, '0'),
(105, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 100, 18, 0, 118, 0, '118'),
(106, 'PHOTOGRAPHER PATEL', '0000-00-00', 2021, 1, 100, 18, 0, 118, '0'),
(107, 'SHEETAL KOLEKAR', '0000-00-00', 1, 100, 18, 0, 118, 0, '118'),
(108, 'SAI KOLEKAR', '0000-00-00', 1, 1, 100, 18, 0, 118, '0'),
(109, 'SAI KOLEKAR', '0000-00-00', 1, 100, 18, 0, 118, 0, '118'),
(110, 'Apurva', '0000-00-00', 1, 100, 18, 0, 118, 0, '118'),
(111, 'Apurva', '0000-00-00', 1, 100, 18, 0, 118, 0, '118'),
(112, 'SHEETAL KOLEKAR', '0000-00-00', 1, 100, 18, 0, 118, 0, '118'),
(113, '2021-15-03', '0000-00-00', 18, 0, 118, 0, 118, 0, 'laptop'),
(114, '2021-15-03', '0000-00-00', 18, 0, 118, 0, 118, 0, 'laptop'),
(115, 'SAI KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(116, 'SHEETAL KOLEKAR', '0000-00-00', 100, 18, 0, 118, 100, 18, 'Cash'),
(117, 'SAI KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(118, 'PHOTOGRAPHER PATEL', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(119, 'SHEETAL KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(120, 'PHOTOGRAPHER PATEL', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(121, 'SHEETAL KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(122, 'SHEETAL KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(123, 'SAI KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(124, 'SAI KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(125, 'SHEETAL KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(126, 'SAI KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(127, 'SHEETAL KOLEKAR', '0000-00-00', 1, 100, 18, 0, 118, 0, '118'),
(128, 'SAI KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(129, 'SAI KOLEKAR', '0000-00-00', 100, 18, 0, 118, 0, 118, 'Cash'),
(130, 'SAI KOLEKAR', '0000-00-00', 300, 54, 0, 354, 0, 354, 'Cash'),
(131, 'SHEETAL KOLEKAR', '0000-00-00', 300, 54, 0, 354, 0, 354, 'Cash'),
(132, 'SHEETAL KOLEKAR', '0000-00-00', 300, 54, 0, 354, 0, 354, 'Cash'),
(133, 'SAI KOLEKAR', '2021-03-15', 600, 108, 0, 708, 0, 708, 'Cash'),
(134, 'PHOTOGRAPHER PATEL', '2021-03-15', 300, 0, 0, 300, 100, 0, 'Cash'),
(135, 'SAI KOLEKAR', '2021-03-15', 3020, 0, 0, 3020, 0, 0, 'Cash'),
(136, 'PHOTOGRAPHER PATEL', '2021-03-15', 300, 0, 0, 300, 100, -100, 'Cash'),
(137, 'KOMAL KOLEKAR', '2021-03-15', 300, 54, 0, 354, 100, 254, 'Cash'),
(138, 'PHOTOGRAPHER PATEL', '2021-03-15', 42000, 7560, 0, 49560, 100, 49460, 'Cash'),
(139, 'PHOTOGRAPHER PATEL', '2021-03-15', 52000, 9360, 0, 61360, 0, 61360, 'Cash'),
(140, 'PHOTOGRAPHER PATEL', '2021-03-15', 100, 0, 0, 100, 0, 118, 'Cash'),
(141, 'PHOTOGRAPHER PATEL', '2021-03-15', 60800, 10944, 0, 71744, 0, 71744, 'Cash'),
(142, 'SHEETAL KOLEKAR', '2021-03-24', 200, 36, 0, 236, 0, 236, 'Cash'),
(143, 'SHEETAL KOLEKAR', '2021-03-31', 100, 0, 0, 100, 0, 100, 'Cash');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_details`
--

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_details`
--

INSERT INTO `invoice_details` (`id`, `invoice_no`, `product_name`, `price`, `qty`) VALUES
(81, 71, '2 sounds', 92660, 1),
(82, 72, 'Entrance', 0, 1),
(83, 73, 'MP MACHINE', 0, 1),
(84, 73, '1 MIKE', 0, 1),
(85, 73, ' 15*15 rain dance', 0, 1),
(86, 73, 'big 15 packet colour', 0, 1),
(87, 73, '2 sounds', 0, 1),
(88, 73, 'catering', 0, 1),
(92, 75, '', 100, 0),
(93, 75, '', 200, 0),
(94, 76, '1 DJ', 0, 1),
(95, 77, '', 100, 0),
(96, 78, '', 100, 0),
(97, 83, '', 29000, 0),
(98, 84, '', 5000, 0),
(99, 85, '', 29000, 0),
(100, 86, '', 29000, 0),
(101, 87, '', 100, 0),
(102, 87, '', 100, 0),
(103, 88, '', 100, 0),
(104, 89, '', 29000, 0),
(105, 90, '', 29000, 0),
(106, 128, 'abcde', 100, 0),
(107, 128, 'laptop', 0, 0),
(108, 129, 'abcde', 100, 0),
(109, 130, 'abcde', 100, 0),
(110, 130, 'laptop', 200, 0),
(111, 131, 'abcde', 100, 0),
(112, 131, 'laptop', 200, 0),
(113, 132, 'abcde', 100, 0),
(114, 132, 'laptop', 200, 0),
(115, 133, 'abcde', 100, 0),
(116, 133, 'abc', 200, 0),
(117, 133, 'laptop', 300, 0),
(118, 134, 'abcde', 0, 0),
(119, 134, 'laptop', 0, 0),
(120, 135, 'laptop', 0, 0),
(121, 135, 'mobile', 0, 0),
(122, 136, 'laptop', 0, 0),
(123, 136, 'mobile', 0, 0),
(124, 137, 'laptop', 100, 0),
(125, 137, 'abcde', 200, 0),
(126, 138, 'laptop', 42000, 0),
(127, 138, 'mobile', 0, 0),
(128, 139, 'laptop', 42000, 0),
(129, 139, 'mobile', 10000, 0),
(130, 140, 'laptop', 100, 0),
(131, 141, 'abcde', 100, 0),
(132, 141, 'abc', 200, 0),
(133, 141, 'laptop', 60000, 0),
(134, 141, 'abcde', 100, 0),
(135, 141, 'abc', 100, 0),
(136, 141, 'abc', 100, 0),
(137, 141, 'abcde', 0, 0),
(138, 141, 'laptop', 100, 0),
(139, 141, 'abcde', 100, 0),
(140, 142, 'abc', 100, 0),
(141, 142, 'laptop', 100, 0),
(142, 143, 'abcde', 100, 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` double NOT NULL,
  `product_stock` int(11) NOT NULL,
  `added_date` date NOT NULL,
  `p_status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `cid`, `bid`, `product_name`, `product_price`, `product_stock`, `added_date`, `p_status`) VALUES
(15, 5, 1, 'Stage Decoration', 0, 0, '2018-01-31', '1'),
(16, 5, 14, 'Vidhi Mandap', 0, 0, '2018-01-31', '1'),
(17, 5, 17, 'Entrance', 0, 0, '2018-01-31', '1'),
(18, 9, 18, 'E Zal Stand', 0, 0, '2018-01-31', '1'),
(19, 1, 17, 'Lawn Decoration', 0, 0, '0000-00-00', ''),
(20, 9, 17, 'Led Light', 0, 0, '0000-00-00', ''),
(21, 10, 18, 'Helogen Light', 0, 0, '0000-00-00', ''),
(22, 1, 17, 'Red Carpet', 0, 0, '0000-00-00', ''),
(23, 1, 17, 'Passage Decoration', 0, 0, '0000-00-00', ''),
(25, 7, 14, 'MP MACHINE', 0, 0, '0000-00-00', ''),
(26, 7, 14, '1 MIKE', 0, 0, '0000-00-00', ''),
(27, 10, 14, '1 DJ', 0, 0, '0000-00-00', ''),
(28, 7, 15, ' 15*15 rain dance', 0, 0, '0000-00-00', ''),
(29, 10, 18, 'big 15 packet colour', 0, 0, '0000-00-00', ''),
(30, 10, 18, '2 sounds', 0, 0, '0000-00-00', ''),
(31, 10, 18, 'catering', 0, 0, '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `usertype` enum('Admin','Other') NOT NULL,
  `register_date` date NOT NULL,
  `last_login` datetime NOT NULL,
  `notes` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `usertype`, `register_date`, `last_login`, `notes`) VALUES
(1, 'Rizwan', 'rizwan@gmail.com', '$2y$08$s11k9wKZWc4v6apSODUdveJufFxbE2Be7rP./uS49et7NrlhteFgK', 'Admin', '2017-12-23', '2018-03-01 04:03:17', ''),
(2, 'Test', 'rizwan1@gmail.com', '$2y$08$8j4aTDZiPZBb3rif4RV/teRFYx2Xv0p9F8CTW3blSafkEhXkMfaV6', 'Admin', '2017-12-23', '2017-12-24 11:12:57', ''),
(3, 'Rizwan', 'rizwankhan.august16@gmail.com', '$2y$08$NmqD7p7Qn7QkEG0/6Sa8v.YhNGo.J2zqfRRGrGRzg1EUlV.9O.M42', 'Admin', '2017-12-24', '2017-12-26 05:12:07', ''),
(4, 'Rizwan', 'rizwankhan@gmail.com', '$2y$08$FsjstZZh5dBNUf.5cZta3e.jZAyfK8pCFaO9AR0jIpQCswNR1bJve', 'Admin', '2017-12-24', '2017-12-25 06:12:18', ''),
(5, 'Imran Khan', 'imran@gmail.com', '$2y$08$KCqI3w9Q1kXFX0W.HDnIYODpMceE6AAbJgygBSQ3au8yZotMyXnCC', 'Admin', '2017-12-25', '2017-12-25 00:00:00', ''),
(6, 'Khan', 'khan@gmail.com', '$2y$08$/4PDGZrGbDPGPEYisj3HBOcaMxRRIBQ1UzHjHKdbzpVMDJJRLry6m', 'Admin', '2017-12-26', '2018-01-15 08:01:14', ''),
(7, 'John Smith', 'john.smith@gmail.com', '$2y$08$cTcxbttxHGTzy0FD3AVjr.m.aNL7p735YRplRiyKZB0kHAOpB9WI2', 'Admin', '2018-02-16', '2018-02-16 05:02:41', ''),
(8, 'sheetal kolekar', 'sk12@gmail.com', '$2y$08$BOz55zXSL7LgVHbDYikyQu2ml508/JNYW0cfKPI2JvP1UkvmCO2Ay', 'Admin', '2021-03-06', '2021-03-11 08:03:49', ''),
(9, 'Tejaswini Mane', 'tej12@gmail.com', '$2y$08$cs5HbBQNbQGDomTMzSk2kuB0G74OqL9/iRBLN/ZWtCF2/EDJ4kx5q', 'Admin', '2021-03-09', '2021-03-09 10:03:35', ''),
(10, 'rahul kolekar', 'rk12@gmail.com', '$2y$08$j0EjuHk15tGGl98h1EZIgut8NTCupsjxqJLA42e/RVSPHwLXHO3fa', 'Admin', '2021-03-09', '2021-03-09 11:03:59', ''),
(11, 'Kolekar Sheetal', 's99@gmail.com', '$2y$08$/xXO9gPQ1M79fsnfQdvBzuXYJ6PUrNHJyWcqRTbFrPg.pZ9d9Z/.e', 'Admin', '2021-03-12', '2021-03-13 05:03:48', ''),
(12, 'Sheetal k', 'sss99@gmail.com', '$2y$08$ztqWYdyyJi0pGF5chbGkx.Bkkg9MdNWHzLuN/qGyNUneSPTQ/uCy6', 'Admin', '2021-03-13', '2021-03-15 04:03:19', ''),
(13, 'Madhuri kolekar', 'mk12@gmail.com', '$2y$08$aYtET0i.AnDyQRpzeYhhs.AZAqE4NXvVd01vUj9JNNk3lLKdvaZM2', 'Admin', '2021-03-22', '2021-03-22 12:03:28', ''),
(14, 'Komal K', 'kk12@gmail.com', '$2y$08$QSSBLbWqrPVh3YRXTtIPm.V7gpx8Yiusbc6WkbbJ/Xm5Cdgk2IrIq', 'Admin', '2021-03-23', '2021-03-23 05:03:26', ''),
(15, 'admin', 'admin12@gmail.com', '$2y$08$9g3ileDaxet6OvdNWldS7eC6YyR2y.KStChSS3qCI99QZSw299Suq', 'Admin', '2021-03-24', '2021-03-24 05:03:01', ''),
(16, 'admin', 'admin@gmail.com', '$2y$08$LUyOsr3OqpiUebfCXk4bQupOsA9zHtlpdCStLFimQXUHu3BciMo9u', 'Admin', '2021-03-31', '2021-03-31 06:03:33', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`bid`),
  ADD UNIQUE KEY `brand_name` (`brand_name`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `clientdetails`
--
ALTER TABLE `clientdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_no`);

--
-- Indexes for table `invoice_details`
--
ALTER TABLE `invoice_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_no` (`invoice_no`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`),
  ADD UNIQUE KEY `product_name` (`product_name`),
  ADD KEY `cid` (`cid`),
  ADD KEY `bid` (`bid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `clientdetails`
--
ALTER TABLE `clientdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoice_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `invoice_details`
--
ALTER TABLE `invoice_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice_details`
--
ALTER TABLE `invoice_details`
  ADD CONSTRAINT `invoice_details_ibfk_1` FOREIGN KEY (`invoice_no`) REFERENCES `invoice` (`invoice_no`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `categories` (`cid`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`bid`) REFERENCES `brands` (`bid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
